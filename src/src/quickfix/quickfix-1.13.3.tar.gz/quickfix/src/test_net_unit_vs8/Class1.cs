using System;
using System.Collections.Generic;
using System.Text;

namespace test_net_unit_vs8
{
	public class Class1
	{
	}
}
