#include "stdafx.h"
#include "MessageStore.h"