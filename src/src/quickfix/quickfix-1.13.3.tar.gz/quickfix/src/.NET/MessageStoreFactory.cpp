#include "stdafx.h"
#include "MessageStoreFactory.h"