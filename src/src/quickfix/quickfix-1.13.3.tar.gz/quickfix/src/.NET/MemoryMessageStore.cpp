#include "stdafx.h"
#include "MemoryMessageStore.h"