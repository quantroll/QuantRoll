#include "stdafx.h"
#include "MySQLStore.h"